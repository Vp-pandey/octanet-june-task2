let todoList = document.getElementById('todo-list');
let newTaskInput = document.getElementById('new-task');
let addTaskButton = document.getElementById('add-task');

let tasks = [];

addTaskButton.addEventListener('click', addTask);

function addTask() {
	let taskText = newTaskInput.value.trim();
	if (taskText!== '') {
		tasks.push({ text: taskText, completed: false });
		newTaskInput.value = '';
		renderTasks();
	}
}

function renderTasks() {
	todoList.innerHTML = '';
	tasks.forEach((task, index) => {
		let taskHTML = `
			<li>
				<input type="checkbox" id="task-${index}" ${task.completed? 'checked' : ''}>
				<label for="task-${index}">${task.text}</label>
			</li>
		`;
		todoList.innerHTML += taskHTML;
	});
}

todoList.addEventListener('click', toggleTask);

function toggleTask(event) {
	if (event.target.type === 'checkbox') {
		let taskIndex = event.target.id.split('-')[1];
		tasks[taskIndex].completed = event.target.checked;
		renderTasks();
	}
}

renderTasks();